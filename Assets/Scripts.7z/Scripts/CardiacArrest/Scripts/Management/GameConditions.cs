public class GameConditions
{
    public float maxTime = 300.0f; // in seconds
    public float distanceToRun = 660.0f; // in meters
}