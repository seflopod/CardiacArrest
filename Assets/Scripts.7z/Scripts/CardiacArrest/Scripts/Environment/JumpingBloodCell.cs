using UnityEngine;
using System.Collections;

public class JumpingBloodCell : BloodCell
{
}