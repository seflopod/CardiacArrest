using UnityEngine;
using System;

[Serializable]
public class PlatformTiles
{
	public int primaryTileIndex = 0;
	public GameObject[] platformTiles;
}